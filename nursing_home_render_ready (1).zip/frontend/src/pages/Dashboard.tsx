import RemindersPanel from '../ui/RemindersPanel'
export default function Dashboard(){
  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-2xl font-bold mb-4">Nursing Home Dashboard</h1>
      <div className="max-w-4xl mx-auto grid grid-cols-3 gap-6">
        <div className="col-span-2">
          <div className="p-4 bg-white rounded-2xl shadow">Main area (patients, tasks, etc.)</div>
        </div>
        <div>
          <RemindersPanel />
        </div>
      </div>
    </div>
  )
}
