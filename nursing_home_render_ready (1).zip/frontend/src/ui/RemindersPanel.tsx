import { useEffect, useState } from 'react';
import { io } from 'socket.io-client';

type Reminder = { medicationId: string; resident: string; medication: string; dosage: string; frequency: string; dueAt: string; };

export default function RemindersPanel(){
  const [reminders, setReminders] = useState<Reminder[]>([]);
  useEffect(()=>{
    const API = (import.meta.env.VITE_API_URL || 'http://localhost:4000');
    const socket = io(API);
    socket.on('connect', ()=> { console.log('socket connected', socket.id) });
    socket.on('reminder', (reminder: Reminder) => { setReminders(prev => [reminder, ...prev]); });
    return ()=> { socket.disconnect() }
  },[]);
  const markAsGiven = async (r: Reminder) => {
    try {
      const nurseId = localStorage.getItem('nurseId') || 'TODO-NURSE-ID';
      const res = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:4000'}/api/mar/log`, {
        method: 'POST', headers: { 'Content-Type':'application/json' }, body: JSON.stringify({ medicationId: r.medicationId, nurseId })
      });
      if (res.ok) { setReminders(prev => prev.filter(x => x.medicationId !== r.medicationId)); alert('Logged as given ✅'); } else { alert('Failed to log'); }
    } catch (err) { console.error(err); alert('Error'); }
  };
  return (
    <div className="p-4 bg-white rounded-2xl shadow-md">
      <h2 className="text-lg font-bold mb-3">Medication Reminders</h2>
      {reminders.length === 0 ? <p className="text-gray-500 text-sm">No reminders yet</p> : (
        <ul className="space-y-2">
          {reminders.map((r, idx) => (
            <li key={idx} className="p-3 rounded-xl bg-red-50 border border-red-200 flex justify-between items-center">
              <div>
                <div className="font-semibold">{r.resident} — {r.medication} ({r.dosage})</div>
                <div className="text-sm text-gray-600">Frequency: {r.frequency} | Due: {new Date(r.dueAt).toLocaleTimeString()}</div>
              </div>
              <button onClick={()=>markAsGiven(r)} className="ml-4 px-3 py-1 bg-green-600 text-white rounded-lg text-sm">Mark as Given</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
