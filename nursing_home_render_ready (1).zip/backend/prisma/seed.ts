import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcrypt';
const prisma = new PrismaClient();
async function main() {
  const passHash = await bcrypt.hash('password', 10);
  const nurse = await prisma.user.upsert({
    where: { email: 'nurse@example.com' },
    update: {},
    create: {
      email: 'nurse@example.com',
      name: 'Nurse Jane',
      password: passHash,
      role: 'NURSE'
    }
  });
  const resident = await prisma.resident.upsert({
    where: { id: '11111111-1111-1111-1111-111111111111' },
    update: {},
    create: { id: '11111111-1111-1111-1111-111111111111', firstName: 'John', lastName: 'Doe', room: '101' }
  });
  const med1 = await prisma.medication.upsert({
    where: { id: '22222222-2222-2222-2222-222222222222' },
    update: {},
    create: {
      id: '22222222-2222-2222-2222-222222222222',
      residentId: resident.id,
      name: 'Paracetamol',
      dosage: '500 mg',
      frequency: '8 hourly',
      route: 'oral',
      prescriber: 'Dr Alice'
    }
  });
  const med2 = await prisma.medication.upsert({
    where: { id: '33333333-3333-3333-3333-333333333333' },
    update: {},
    create: {
      id: '33333333-3333-3333-3333-333333333333',
      residentId: resident.id,
      name: 'Amoxicillin',
      dosage: '250 mg',
      frequency: '12 hourly',
      route: 'oral',
      prescriber: 'Dr Bob'
    }
  });
  console.log('Seed completed');
}
main().catch(e => { console.error(e); process.exit(1); }).finally(async () => { await (new PrismaClient()).$disconnect(); });
