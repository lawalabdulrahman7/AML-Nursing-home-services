import { Worker } from 'bullmq';
import { prisma } from '../prismaClient';
import dotenv from 'dotenv';
dotenv.config();
export const reminderWorker = new Worker('medication-reminders', async job => { const { medicationId } = job.data; const med = await prisma.medication.findUnique({ where: { id: medicationId }, include: { resident: true } }); if (!med) return; console.log(`Reminder job for med ${med.name} (resident ${med.resident.firstName} ${med.resident.lastName})`); }, { connection: { url: process.env.REDIS_URL || 'redis://localhost:6379' } });
