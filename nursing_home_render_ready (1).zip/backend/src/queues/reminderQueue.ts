import { Queue } from 'bullmq';
import { RedisOptions } from 'ioredis';
import dotenv from 'dotenv';
dotenv.config();
const redisOptions: RedisOptions = { maxRetriesPerRequest: null, enableReadyCheck: false };
export const reminderQueue = new Queue('medication-reminders', { connection: { url: process.env.REDIS_URL || 'redis://localhost:6379', ...redisOptions } });
