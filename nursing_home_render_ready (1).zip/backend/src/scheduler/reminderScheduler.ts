import { prisma } from '../prismaClient';
import { reminderQueue } from '../queues/reminderQueue';
import dotenv from 'dotenv';
dotenv.config();
const INTERVAL = parseInt(process.env.REMINDER_CHECK_INTERVAL || '60000');
function parseFrequencyToHours(freq: string): number { const match = freq.match(/(\\d+)\\s*hour/i); if (match) return parseInt(match[1]); const match2 = freq.match(/(\\d+)\\s*hr/i); if (match2) return parseInt(match2[1]); return 8; }
export async function runReminderScheduler() { setInterval(async () => { try { const meds = await prisma.medication.findMany({ where: { active: true } }); for (const med of meds) { const hours = parseFrequencyToHours(med.frequency || '8 hourly'); const lastLog = await prisma.marLog.findFirst({ where: { medicationId: med.id }, orderBy: { administeredAt: 'desc' } }); const nextDue = lastLog?.administeredAt ? new Date(lastLog.administeredAt.getTime() + hours * 3600 * 1000) : new Date(med.startDate); if (nextDue.getTime() <= Date.now()) { await reminderQueue.add('reminder', { medicationId: med.id }); } } } catch (err) { console.error('Scheduler error', err); } }, INTERVAL); }
