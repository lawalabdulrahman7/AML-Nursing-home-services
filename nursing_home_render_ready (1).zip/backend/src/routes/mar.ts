import { Router } from 'express';
import { prisma } from '../prismaClient';
const router = Router();
router.post('/log', async (req, res) => {
  const { medicationId, nurseId } = req.body;
  if (!medicationId || !nurseId) return res.status(400).json({ error: 'Missing fields' });
  const log = await prisma.marLog.create({ data: { medicationId, administeredBy: nurseId, administeredAt: new Date(), status: 'GIVEN' } });
  res.json({ success: true, log });
});
router.get('/medication/:medicationId', async (req, res) => {
  const logs = await prisma.marLog.findMany({ where: { medicationId: req.params.medicationId } });
  res.json(logs);
});
export default router;
