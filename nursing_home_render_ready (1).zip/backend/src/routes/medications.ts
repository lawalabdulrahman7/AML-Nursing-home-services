import { Router } from 'express';
import { prisma } from '../prismaClient';
const router = Router();
router.get('/resident/:residentId', async (req, res) => {
  const residentId = req.params.residentId;
  const meds = await prisma.medication.findMany({ where: { residentId } });
  res.json(meds);
});
export default router;
