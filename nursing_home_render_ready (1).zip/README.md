# Nursing Home MVP — Render Deployment (Ready)

This repository is prepared to deploy a simple Nursing Home MVP to **Render** with preconfigured seed data (a test nurse, a resident, and two medications).

## Overview
- **Backend**: Node.js + Express + TypeScript + Prisma (Postgres) + BullMQ (Redis) + Socket.IO
- **Frontend**: React (Vite) — simple dashboard with Real-time Reminders Panel

## What is preconfigured
- Prisma seed script (`prisma/seed.ts`) creates:
  - A nurse user (email: `nurse@example.com`, password: `password`)
  - A resident (John Doe)
  - Two medications for John Doe

## How to deploy to Render (step-by-step)

### 1) Create a GitHub repository
1. Create a GitHub account if you don't have one: https://github.com/join
2. Create a new repository (e.g. `nursing-home-mvp`) and push the contents of this folder.

### 2) Create a Render account
1. Sign up at https://render.com
2. Connect your GitHub account to Render when prompted.

### 3) Create a Postgres database on Render
1. In Render, go to "New" → "Postgres Database" → choose a plan (free tier available).
2. After creation, copy the DATABASE_URL from Render (Connection string). Keep this for later.

### 4) Create a Redis instance on Render
1. In Render, go to "New" → "Redis" → create a Redis instance.
2. Save the REDIS_URL connection string.

### 5) Deploy Backend (API)
1. In Render, click "New" → "Web Service".
2. Select the GitHub repo and the backend directory (select the root if you uploaded the whole repo).
3. For the build command, use: `npm install && npm run build && npx prisma generate`
4. For the start command, use: `npm start`
5. In Environment, add these environment variables (use the values from your Render Postgres/Redis services):
   - `DATABASE_URL` = your Render Postgres connection string
   - `REDIS_URL` = your Redis URL
   - `JWT_SECRET` = a strong secret
   - `REMINDER_CHECK_INTERVAL` = `60000`
6. In the Advanced > Health Check route set `/health`.

### 6) Seed the Database (one-time)
After the backend service is deployed and running, open Shell for the service and run:
```
npm run seed
```

### 7) Deploy Frontend (Static Site)
1. In Render, click "New" → "Static Site".
2. Select the same GitHub repo and set the build command to: `npm install && npm run build` and the publish directory to `frontend/dist`.
3. Add an environment variable (in the static site settings):
   - `VITE_API_URL` = the URL of your deployed backend (e.g. `https://your-backend.onrender.com`)

### 8) Open the frontend URL
Visit the static site URL Render gives you. The dashboard should connect to the backend and start receiving reminders.
